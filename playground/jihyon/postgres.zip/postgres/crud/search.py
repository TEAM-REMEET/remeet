"""회의 검색 (web views/search.py 의 탭: 회의명 · 폴더명 · 구성원 · 회의 내용).

검색 범위 = 내가 볼 수 있는 회의 (crud/minutes 의 목록과 같은 규칙 · 남의 미리보기 제외).
글자 일부 포함 검색(대소문자 무시) · migrations/009 의 pg_trgm 인덱스로 빠르게.

    search_titles(q)                 회의명
    search_folders(q)                프로젝트 폴더 이름 + 정기 회의 폴더(2026년 · 10월 · 4주차 · 2026.10.23)
    search_people(people)            그 사람이 주관 · 참석한 회의 + 그 사람의 발언 조금
                                     people = {user_id: 이름} — 이름으로 사람 찾기는 구성원 표(팀원 담당)에서 하고 넘겨 줌
    search_content(q)                원문 발화 · 요약 · 결정 사항 · 액션 아이템 (원문은 원문 권한이 있을 때만)
    search_all(q)                    탭별 결과 수 + 결과 (화면 첫 진입용)
"""
from __future__ import annotations

from db import transaction
from .common import ValidationError, require_user
from .minutes import _DAY, _LATEST, _VISIBLE, list_regular_tree

MAX_RESULTS = 100


def _q(q: str) -> str:
    q = (q or "").strip()
    if not q:
        raise ValidationError("검색어를 입력해 주세요.")
    if len(q) > 100:
        raise ValidationError("검색어가 너무 깁니다 (100자까지).")
    return q


def _like(q: str) -> str:
    """ILIKE 패턴 — %, _ 같은 특수 글자는 글자 그대로 찾게."""
    return "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"


# 내가 볼 수 있는 회의 + 원문을 봐도 되는지(raw_ok) — crud/common.can_view_raw 와 같은 규칙
_VIS_CTE = f"""
WITH vis AS (
  SELECT m.id, m.title, m.type_id, m.folder_id, f.name AS folder_name, m.host_user_id,
         {_LATEST} AS sort_at, to_char({_DAY}, 'YYYY.MM.DD') AS date_label,
         (%(actor)s IN (m.host_user_id, m.created_by, m.reviewer_id)
          OR EXISTS (SELECT 1 FROM meeting_attendees a WHERE a.meeting_id = m.id AND a.user_id = %(actor)s)
          OR (NOT EXISTS (SELECT 1 FROM meeting_shares s WHERE s.meeting_id = m.id
                          AND s.recipient_user_id = %(actor)s AND s.revoked_at IS NULL)
              AND f.id IS NOT NULL
              AND (f.host_user_id = %(actor)s
                   OR EXISTS (SELECT 1 FROM folder_members fm WHERE fm.folder_id = f.id AND fm.user_id = %(actor)s)))
          OR EXISTS (SELECT 1 FROM meeting_shares s WHERE s.meeting_id = m.id AND s.recipient_user_id = %(actor)s
                     AND s.revoked_at IS NULL AND s.scope = 'full' AND NOT s.lock_raw)) AS raw_ok,
         (SELECT ms.id FROM meeting_summaries ms WHERE ms.meeting_id = m.id ORDER BY ms.version DESC LIMIT 1) AS sid
  FROM meetings m LEFT JOIN folders f ON f.id = m.folder_id AND f.deleted_at IS NULL
  WHERE {_VISIBLE}
)
"""


def search_titles(*, actor_id: str, q: str, limit: int = MAX_RESULTS) -> list[dict]:
    """[회의명] 제목에 검색어가 들어간 회의 (최신순) + 요약 앞부분."""
    q = _q(q)
    with transaction(actor_id) as cur:
        require_user(cur, actor_id)
        cur.execute(
            _VIS_CTE + """
            SELECT v.id, v.title, v.type_id, v.folder_id, v.folder_name, v.host_user_id, v.date_label,
                   left(s.overview, 200) AS summary_preview
            FROM vis v LEFT JOIN meeting_summaries s ON s.id = v.sid
            WHERE v.title ILIKE %(like)s
            ORDER BY v.sort_at DESC, v.id DESC LIMIT %(limit)s""",
            {"actor": actor_id, "like": _like(q), "limit": limit},
        )
        return cur.fetchall()


def search_folders(*, actor_id: str, q: str) -> list[dict]:
    """[폴더명] 프로젝트 폴더(이름) + 정기 회의 폴더(「2026년」 「10월」 「4주차」 「10월 4주차」 「2026.10.23」).
    띄어쓰기는 무시하고 비교. [{kind: project|regular, id|type_id+key, label, path, count, latest_title, …}]"""
    q = _q(q)
    out = []
    with transaction(actor_id) as cur:
        require_user(cur, actor_id)
        cur.execute(
            f"""SELECT f.id, f.name, count(m.id) AS count, max({_LATEST}) AS last_meeting_at,
                       (array_agg(m.title ORDER BY {_LATEST} DESC) FILTER (WHERE m.id IS NOT NULL))[1] AS latest_title,
                       (SELECT count(*) FROM folder_members x WHERE x.folder_id = f.id) AS member_count
                FROM folders f
                LEFT JOIN meetings m ON m.folder_id = f.id AND m.deleted_at IS NULL
                     AND (m.status <> 'draft' OR %(actor)s IN (m.created_by, m.host_user_id))
                WHERE f.deleted_at IS NULL AND f.name ILIKE %(like)s
                  AND (f.host_user_id = %(actor)s
                       OR EXISTS (SELECT 1 FROM folder_members fm WHERE fm.folder_id = f.id AND fm.user_id = %(actor)s))
                GROUP BY f.id ORDER BY max({_LATEST}) DESC NULLS LAST, f.sort_order""",
            {"actor": actor_id, "like": _like(q)},
        )
        out += [{"kind": "project", "label": r["name"], "path": ["프로젝트", r["name"]], **r} for r in cur.fetchall()]

    needle = q.replace(" ", "").lower()

    def walk(type_id, nodes, path):
        for n in nodes:
            labels = path + [n["label"]]
            # 「10월 4주차」처럼 위 폴더 이름과 이어서 찾아도 걸리게 (종류 이름 뒤의 경로 전체 · 끝부분)
            tails = ["".join(labels[i:]) for i in range(1, len(labels))]
            if any(needle in t.lower() for t in tails):
                out.append({"kind": "regular", "type_id": type_id, "key": n["key"], "label": n["label"],
                            "path": ["정기 회의", *labels], "count": n["count"],
                            "last_meeting_at": n["last_meeting_at"], "latest_title": n["latest_title"]})
            walk(type_id, n["children"], labels)

    for t in list_regular_tree(actor_id=actor_id):
        walk(t["type_id"], t["children"], [t["label"]])
    return out


def search_people(*, actor_id: str, people: dict[str, str], limit: int = MAX_RESULTS) -> list[dict]:
    """[구성원] people = {user_id: 이름}. 그 사람이 주관 · 참석한 회의 (최신순) + 그 사람의 발언 2개.
    발언은 원문 권한이 있을 때만, 화자 이름(speaker)이나 화자 매핑(meeting_speakers.user_id)으로 찾음."""
    if not people:
        return []
    ids, names = list(people), list(people.values())
    with transaction(actor_id) as cur:
        require_user(cur, actor_id)
        cur.execute(
            _VIS_CTE + """
            , ppl AS (SELECT * FROM unnest(%(ids)s::text[], %(names)s::text[]) AS p(user_id, name))
            , hit AS (
              SELECT v.*, p.user_id, p.name, (p.user_id = v.host_user_id) AS is_host
              FROM vis v JOIN ppl p
                ON p.user_id = v.host_user_id
                OR EXISTS (SELECT 1 FROM meeting_attendees a WHERE a.meeting_id = v.id AND a.user_id = p.user_id)
            )
            SELECT h.id, h.title, h.folder_id, h.folder_name, h.type_id, h.date_label, h.user_id, h.name,
                   CASE WHEN h.is_host THEN '주관' ELSE '참석' END AS role,
                   CASE WHEN h.raw_ok THEN (
                     SELECT COALESCE(array_agg(x.text ORDER BY x.position), '{}') FROM (
                       SELECT t.text, t.position FROM transcript_lines t
                       WHERE t.meeting_id = h.id AND t.speaker <> ''
                         AND (t.speaker = h.name
                              OR EXISTS (SELECT 1 FROM meeting_speakers sp WHERE sp.meeting_id = h.id
                                         AND sp.label = t.speaker AND sp.user_id = h.user_id))
                       ORDER BY t.position LIMIT 2) x)
                   ELSE '{}' END AS said
            FROM hit h ORDER BY h.sort_at DESC, h.id DESC, h.user_id LIMIT %(limit)s""",
            {"actor": actor_id, "ids": ids, "names": names, "limit": limit},
        )
        return cur.fetchall()


def search_content(*, actor_id: str, q: str, limit: int = MAX_RESULTS) -> list[dict]:
    """[회의 내용] 원문 발화(원문 권한 있을 때만) · 최신 요약 · 결정 사항 · 액션 아이템에서 찾기.
    회의마다 1줄: matches(찾은 곳 수) · snippets(앞 2곳: {where, text, line_id}) — line_id 로 원문 위치로 이동."""
    q = _q(q)
    with transaction(actor_id) as cur:
        require_user(cur, actor_id)
        cur.execute(
            _VIS_CTE + """
            , found AS (
              SELECT v.id, 'transcript' AS "where", t.text, t.line_id, t.position AS ord
              FROM vis v JOIN transcript_lines t ON t.meeting_id = v.id
              WHERE v.raw_ok AND t.speaker <> '' AND t.text ILIKE %(like)s
              UNION ALL
              SELECT v.id, 'summary', s.overview, NULL, -3 FROM vis v JOIN meeting_summaries s ON s.id = v.sid
              WHERE s.overview ILIKE %(like)s
              UNION ALL
              SELECT v.id, 'decision', p.text, NULL, -2 FROM vis v JOIN summary_points p ON p.summary_id = v.sid
              WHERE p.section = 'decision' AND p.text ILIKE %(like)s
              UNION ALL
              SELECT v.id, 'todo', d.text, NULL, -1 FROM vis v JOIN meeting_todos d ON d.meeting_id = v.id
              WHERE d.deleted_at IS NULL AND d.text ILIKE %(like)s
            )
            SELECT v.id, v.title, v.folder_id, v.folder_name, v.type_id, v.host_user_id, v.date_label,
                   count(*) AS matches,
                   (array_agg(json_build_object('where', fo."where", 'text', fo.text, 'line_id', fo.line_id)
                              ORDER BY fo.ord))[1:2] AS snippets
            FROM found fo JOIN vis v ON v.id = fo.id
            GROUP BY v.id, v.title, v.folder_id, v.folder_name, v.type_id, v.host_user_id, v.date_label, v.sort_at
            ORDER BY v.sort_at DESC, v.id DESC LIMIT %(limit)s""",
            {"actor": actor_id, "like": _like(q), "limit": limit},
        )
        return cur.fetchall()


def search_all(*, actor_id: str, q: str, people: dict[str, str] | None = None) -> dict:
    """탭별 결과 한 번에 (people 은 구성원 표에서 이름으로 찾은 {user_id: 이름})."""
    res = {"title": search_titles(actor_id=actor_id, q=q), "folder": search_folders(actor_id=actor_id, q=q),
           "people": search_people(actor_id=actor_id, people=people or {}),
           "content": search_content(actor_id=actor_id, q=q)}
    return {"counts": {k: len(v) for k, v in res.items()}, **res}
