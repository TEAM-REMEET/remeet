"""회의 원본 · 회의 목록(전체 / 프로젝트별).  ※ 요약 · 회의 상세는 crud/detail.py

    원본   meeting_sources      올린 회의록 파일 그대로 (다시 올리면 version + 1)
    목록   정기 회의 (프로젝트에 안 넣은 회의)
             월간 회의 ─ 2026년 ─ 10월            list_regular_tree() · list_regular_meetings(type_id, period=key)
             주간 회의 ─ 2026년 ─ 10월 ─ 4주차
             일반 회의 ─ 2026.10.23
           프로젝트 ─ 프로젝트 폴더 ─ 2026.10.27   list_project_folders() · list_project_meetings()
           회의 하나는 둘 중 한 곳에만 (folder_id 가 있으면 프로젝트). 목록은 모두 최신 날짜순.

권한 (crud/common.py 와 같은 규칙)
    목록에 나오는 회의 = 주관 · 참석 · 프로젝트 폴더 주관자/멤버 · 공유받음
    원본 보기   = 원문 보기 권한 (can_view_raw: 요약만 공유받은 사람은 못 봄)
    원본 쓰기   = 회의 주관자만

"최신순" 기준은 회의 날짜(meetings.held_at). 날짜를 모르는 회의는 만든 시각(created_at)으로 정렬.

사용 예
    from crud import minutes
    minutes.add_source(actor_id='u1', meeting_id='m1', file_name='회의.txt', content_text='A: 시작할게요 ...')
    minutes.list_regular_tree(actor_id='u1')                 # 정기 회의 폴더 트리 (+ 회의 수)
    minutes.list_regular_meetings(actor_id='u1', type_id='weekly', period='2026-10-w4')   # 주간 > 2026년 > 10월 > 4주차
    minutes.list_project_folders(actor_id='u1')              # 프로젝트별 탭: 폴더 목록
    minutes.list_project_meetings(actor_id='u1', folder_id='rel')   # 폴더 안 회의록
"""
from __future__ import annotations

import hashlib

from db import transaction
from .common import (
    NotFoundError,
    PermissionDenied,
    ValidationError,
    can_access_folder,
    can_access_meeting,
    can_view_raw,
    invalidate,
    require_user,
    required,
)

ORIGINS = frozenset({"ai", "edited"})
MAX_PAGE = 200

# 목록에 쓰는 정렬 기준 (schema.sql 의 meetings_*latest_idx 인덱스와 같은 식)
_LATEST = "COALESCE(m.held_at, m.created_at)"
# 회의 날짜 (한국 시간) · 그 주 월요일 · 폴더 키
_DAY = f"(({_LATEST} AT TIME ZONE 'Asia/Seoul')::date)"
_MONDAY = f"({_DAY} - (EXTRACT(ISODOW FROM {_DAY})::int - 1))"
# 정기 회의 폴더 키 — 월간: 2026-10 · 주간: 2026-10-w4 (그 주 월요일 기준 몇째 주) · 일반: 2026-10-23
_PERIOD_KEY = f"""(CASE m.type_id
    WHEN 'monthly' THEN to_char({_DAY}, 'YYYY-MM')
    WHEN 'weekly'  THEN to_char({_MONDAY}, 'YYYY-MM') || '-w' || ((EXTRACT(DAY FROM {_MONDAY})::int - 1) / 7 + 1)
    ELSE to_char({_DAY}, 'YYYY-MM-DD') END)"""

# 목록 한 줄에 같이 보여 줄 것: 폴더 이름, 최신 요약 version · 첫 부분, 원본 있는지
_LIST_COLUMNS = f"""
    m.id, m.title, m.held_at, {_LATEST} AS sort_at, to_char({_DAY}, 'YYYY.MM.DD') AS date_label,
    {_PERIOD_KEY} AS period_key, m.time_label, m.status,
    m.type_id, mt.name AS type_name, m.folder_id, f.name AS folder_name, m.host_user_id, m.file_name,
    EXISTS (SELECT 1 FROM meeting_shares x WHERE x.meeting_id = m.id AND x.recipient_user_id = %(actor)s
            AND x.revoked_at IS NULL) AS shared_to_me,
    s.version AS summary_version, left(s.overview, 200) AS summary_preview,
    EXISTS (SELECT 1 FROM meeting_sources src WHERE src.meeting_id = m.id) AS has_source
"""
_LATEST_SUMMARY_JOIN = """
    JOIN meeting_types mt ON mt.id = m.type_id
    LEFT JOIN LATERAL (
        SELECT version, overview FROM meeting_summaries ms
        WHERE ms.meeting_id = m.id ORDER BY version DESC LIMIT 1
    ) s ON TRUE
"""


def _page(limit: int, offset: int) -> tuple[int, int]:
    if not (1 <= limit <= MAX_PAGE) or offset < 0:
        raise ValidationError(f"limit 은 1~{MAX_PAGE}, offset 은 0 이상이어야 합니다.")
    return limit, offset


def _lock_meeting(cur, meeting_id: str) -> None:
    """version 번호를 매길 때 두 요청이 같은 번호를 받지 않도록 회의 행을 잠금."""
    cur.execute("SELECT 1 FROM meetings WHERE id = %s FOR UPDATE", (meeting_id,))


def _next_version(cur, table: str, meeting_id: str) -> int:
    # table 은 이 파일 안의 고정 값만 들어옴 (사용자 입력 아님)
    cur.execute(f"SELECT COALESCE(MAX(version), 0) + 1 AS v FROM {table} WHERE meeting_id = %s", (meeting_id,))
    return cur.fetchone()["v"]


# =====================================================================
# 회의 원본
# =====================================================================
def add_source(*, actor_id: str, meeting_id: str, file_name: str,
               content_text: str | None = None, storage_uri: str | None = None,
               mime_type: str = "text/plain", size_bytes: int | None = None) -> dict:
    """회의 원본 올리기. 텍스트는 content_text, 음성 · 큰 파일은 저장소에 올린 뒤 storage_uri."""
    if not content_text and not storage_uri:
        raise ValidationError("원본 내용(content_text) 또는 파일 경로(storage_uri)가 필요합니다.")
    digest = None
    if content_text:
        raw = content_text.encode("utf-8")
        digest = hashlib.sha256(raw).hexdigest()
        size_bytes = len(raw) if size_bytes is None else size_bytes
    with transaction(actor_id) as cur:
        can_access_meeting(cur, meeting_id, actor_id, write=True)
        _lock_meeting(cur, meeting_id)
        version = _next_version(cur, "meeting_sources", meeting_id)
        cur.execute(
            """INSERT INTO meeting_sources
                   (meeting_id, version, file_name, mime_type, content_text, storage_uri,
                    size_bytes, sha256, uploaded_by)
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
               RETURNING id, meeting_id, version, file_name, mime_type, storage_uri,
                         size_bytes, sha256, uploaded_by, uploaded_at""",
            (meeting_id, version, required(file_name, "파일 이름"), mime_type, content_text,
             storage_uri, size_bytes, digest, actor_id),
        )
        row = cur.fetchone()
        # 목록 화면의 파일 이름도 최신 원본으로
        cur.execute("UPDATE meetings SET file_name = %s WHERE id = %s", (row["file_name"], meeting_id))
    invalidate("_base_meetings")
    return row


def get_source(*, actor_id: str, meeting_id: str, version: int | None = None) -> dict:
    """원본 1벌 (내용 포함). version 을 안 주면 최신."""
    with transaction(actor_id) as cur:
        if not can_view_raw(cur, meeting_id, actor_id):
            raise PermissionDenied("회의 원본 열람 권한이 없습니다.")
        cur.execute(
            """SELECT * FROM meeting_sources WHERE meeting_id = %s
                 AND (%s::int IS NULL OR version = %s::int)
               ORDER BY version DESC LIMIT 1""",
            (meeting_id, version, version),
        )
        row = cur.fetchone()
    if row is None:
        raise NotFoundError("회의 원본이 없습니다.")
    return row


def list_sources(*, actor_id: str, meeting_id: str) -> list[dict]:
    """원본 버전 목록 (내용은 빼고 정보만). 최신 버전이 먼저."""
    with transaction(actor_id) as cur:
        if not can_view_raw(cur, meeting_id, actor_id):
            raise PermissionDenied("회의 원본 열람 권한이 없습니다.")
        cur.execute(
            """SELECT id, version, file_name, mime_type, storage_uri, size_bytes, sha256,
                      uploaded_by, uploaded_at
               FROM meeting_sources WHERE meeting_id = %s ORDER BY version DESC""",
            (meeting_id,),
        )
        return cur.fetchall()


# =====================================================================
# 회의 목록: 정기 회의 / 프로젝트
# =====================================================================
# 내가 볼 수 있는 회의 (crud/common.can_access_meeting 과 같은 규칙). f = 살아 있는 폴더 LEFT JOIN
_VISIBLE = """
    m.deleted_at IS NULL
    AND (m.status <> 'draft' OR %(actor)s IN (m.created_by, m.host_user_id))   -- 미리보기는 작성자 · 주관자만
    AND (
        m.host_user_id = %(actor)s OR m.created_by = %(actor)s OR m.reviewer_id = %(actor)s
        OR EXISTS (SELECT 1 FROM meeting_attendees ma WHERE ma.meeting_id = m.id AND ma.user_id = %(actor)s)
        OR f.host_user_id = %(actor)s
        OR EXISTS (SELECT 1 FROM folder_members fm WHERE fm.folder_id = f.id AND fm.user_id = %(actor)s)
        OR EXISTS (SELECT 1 FROM meeting_shares sh
                   WHERE sh.meeting_id = m.id AND sh.recipient_user_id = %(actor)s AND sh.revoked_at IS NULL)
    )
"""


REGULAR_TYPES = ("monthly", "weekly", "normal")   # 화면 순서


def _period_filter(type_id: str, period: str | None) -> str | None:
    """폴더 키 검사: 2026 · 2026-10 · 2026-10-w4(주간) · 2026-10-23(일반)."""
    import re
    if period is None:
        return None
    ok = {"monthly": r"\d{4}(-\d{2})?", "weekly": r"\d{4}(-\d{2}(-w[1-5])?)?",
          "normal": r"\d{4}(-\d{2}(-\d{2})?)?"}.get(type_id, r"\d{4}(-\d{2}(-\d{2})?)?")
    if not re.fullmatch(ok, period):
        raise ValidationError(f"폴더 키 형식이 잘못됐습니다: {period}")
    return period


def _node(key: str, label: str) -> dict:
    return {"key": key, "label": label, "count": 0, "last_meeting_at": None, "latest_title": None, "children": []}


def list_regular_tree(*, actor_id: str) -> list[dict]:
    """[정기 회의] 폴더 트리 (프로젝트에 안 들어간 회의 · 내가 볼 수 있는 것만 · 최근 폴더가 먼저).

        월간 회의 ─ 2026년 ─ 10월            key: 2026 → 2026-10
        주간 회의 ─ 2026년 ─ 10월 ─ 4주차    key: 2026 → 2026-10 → 2026-10-w4  (그 주 월요일이 속한 달 · 몇째 주)
        일반 회의 ─ 2026.10.23               key: 2026-10-23

    [{type_id, label, count, last_meeting_at, latest_title, children: [{key, label, count, …, children}]}]
    폴더 안 회의 목록은 list_regular_meetings(type_id, period=key).
    """
    with transaction(actor_id) as cur:
        require_user(cur, actor_id)
        cur.execute("SELECT id, name FROM meeting_types ORDER BY sort_order, id")
        names = {r["id"]: r["name"] for r in cur.fetchall()}
        cur.execute(
            f"""SELECT m.type_id, {_PERIOD_KEY} AS k, {_LATEST} AS sort_at, m.title
                FROM meetings m LEFT JOIN folders f ON f.id = m.folder_id AND f.deleted_at IS NULL
                WHERE m.folder_id IS NULL AND {_VISIBLE}
                ORDER BY {_LATEST} DESC, m.id DESC""",
            {"actor": actor_id},
        )
        rows = cur.fetchall()

    types = [t for t in REGULAR_TYPES if t in names] + [t for t in names if t not in REGULAR_TYPES]
    tree = {t: {"type_id": t, **_node(t, names[t])} for t in types}
    index: dict[tuple, dict] = {}

    def child(parent: dict, key: str, label: str) -> dict:
        if (id(parent), key) not in index:
            index[(id(parent), key)] = _node(key, label)
            parent["children"].append(index[(id(parent), key)])   # 행이 최신순이라 최근 폴더가 먼저 붙음
        return index[(id(parent), key)]

    for r in rows:
        k, t = r["k"], r["type_id"]
        if t == "monthly":
            path = [(k[:4], f"{k[:4]}년"), (k, f"{int(k[5:7])}월")]
        elif t == "weekly":
            path = [(k[:4], f"{k[:4]}년"), (k[:7], f"{int(k[5:7])}월"), (k, f"{k[9:]}주차")]
        else:
            path = [(k, k.replace("-", "."))]
        nodes = [tree[t]]
        for key, label in path:
            nodes.append(child(nodes[-1], key, label))
        for n in nodes:
            n["count"] += 1
            if n["last_meeting_at"] is None:                         # 첫 행 = 가장 최근 회의
                n["last_meeting_at"], n["latest_title"] = r["sort_at"], r["title"]
    return list(tree.values())


def list_regular_meetings(*, actor_id: str, type_id: str, period: str | None = None,
                          limit: int = 50, offset: int = 0) -> list[dict]:
    """[정기 회의 > 종류 > 폴더] 회의 목록, 최신 날짜순.
    period = list_regular_tree 의 key (2026 · 2026-10 · 2026-10-w4 · 2026-10-23). 안 주면 그 종류 전부."""
    limit, offset = _page(limit, offset)
    period = _period_filter(type_id, period)
    with transaction(actor_id) as cur:
        require_user(cur, actor_id)
        cur.execute(
            f"""
            SELECT {_LIST_COLUMNS}
            FROM meetings m
            LEFT JOIN folders f ON f.id = m.folder_id AND f.deleted_at IS NULL
            {_LATEST_SUMMARY_JOIN}
            WHERE m.folder_id IS NULL AND m.type_id = %(type)s AND {_VISIBLE}
              AND (%(period)s::text IS NULL OR {_PERIOD_KEY} = %(period)s OR {_PERIOD_KEY} LIKE %(period)s || '-%%')
            ORDER BY {_LATEST} DESC, m.id DESC
            LIMIT %(limit)s OFFSET %(offset)s
            """,
            {"actor": actor_id, "type": type_id, "period": period, "limit": limit, "offset": offset},
        )
        return cur.fetchall()


def list_all_meetings(*, actor_id: str, limit: int = 50, offset: int = 0) -> list[dict]:
    """내가 볼 수 있는 회의 전부 (정기 + 프로젝트 + 공유받은 것), 최신 날짜순. 홈 · 최근 회의 등에.
    공유받기만 한 회의는 shared_to_me = True."""
    limit, offset = _page(limit, offset)
    with transaction(actor_id) as cur:
        require_user(cur, actor_id)
        cur.execute(
            f"""
            SELECT {_LIST_COLUMNS}
            FROM meetings m
            LEFT JOIN folders f ON f.id = m.folder_id AND f.deleted_at IS NULL
            {_LATEST_SUMMARY_JOIN}
            WHERE {_VISIBLE}
            ORDER BY {_LATEST} DESC, m.id DESC
            LIMIT %(limit)s OFFSET %(offset)s
            """,
            {"actor": actor_id, "limit": limit, "offset": offset},
        )
        return cur.fetchall()


def list_project_folders(*, actor_id: str) -> list[dict]:
    """[프로젝트] 내가 볼 수 있는 프로젝트 폴더 목록 + 회의 수 · 마지막 회의 날짜.
    폴더 순서는 기존 list_folders 와 같음 (sort_order → 만든 순)."""
    with transaction(actor_id) as cur:
        require_user(cur, actor_id)
        cur.execute(
            f"""
            SELECT f.id, f.name, f.type_id, f.host_user_id, f.sort_order, f.created_at,
                   count(m.id)  AS meeting_count,
                   max({_LATEST}) AS last_meeting_at
            FROM folders f
            LEFT JOIN meetings m ON m.folder_id = f.id AND m.deleted_at IS NULL
                 AND (m.status <> 'draft' OR %(actor)s IN (m.created_by, m.host_user_id))
            WHERE f.deleted_at IS NULL
              AND (f.host_user_id = %(actor)s
                   OR EXISTS (SELECT 1 FROM folder_members fm
                              WHERE fm.folder_id = f.id AND fm.user_id = %(actor)s))
            GROUP BY f.id
            ORDER BY f.sort_order, f.created_at
            """,
            {"actor": actor_id},
        )
        return cur.fetchall()


def list_project_meetings(*, actor_id: str, folder_id: str,
                          limit: int = 50, offset: int = 0) -> list[dict]:
    """[프로젝트 > 프로젝트 폴더] 회의록 목록, 최신 날짜순 (각 줄의 date_label = 2026.10.27)."""
    limit, offset = _page(limit, offset)
    with transaction(actor_id) as cur:
        can_access_folder(cur, folder_id, actor_id)
        cur.execute(
            f"""
            SELECT {_LIST_COLUMNS}
            FROM meetings m
            JOIN folders f ON f.id = m.folder_id
            {_LATEST_SUMMARY_JOIN}
            WHERE m.folder_id = %(folder)s AND m.deleted_at IS NULL
              AND (m.status <> 'draft' OR %(actor)s IN (m.created_by, m.host_user_id))
            ORDER BY {_LATEST} DESC, m.id DESC
            LIMIT %(limit)s OFFSET %(offset)s
            """,
            {"actor": actor_id, "folder": folder_id, "limit": limit, "offset": offset},
        )
        return cur.fetchall()
